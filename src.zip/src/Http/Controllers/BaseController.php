<?php

namespace LnjGroup\Cms\Http\Controllers;

use App\Http\Controllers\Controller;

class BaseController extends Controller
{

}