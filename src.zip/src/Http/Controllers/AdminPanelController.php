<?php

namespace LnjGroup\Cms\Http\Controllers;

use App\Http\Controllers\Controller;
use App\User;
use LnjGroup\Cms\Models\Admin;

class AdminPanelController extends BaseController
{
    public function index()
    {
        return \Cms::listAdmin();
    }
}