<?php

Route::group(['middleware' => 'admin:protected', 'namespace' => 'LnjGroup\Cms\Http\Controllers'], function () {
    Route::get('/adminpanel/index', 'AdminPanelController@index');
    Route::get('/adminpanel/config', function () {
        return config('cms.name');
    });

});


