<?php

/**
 * Created by PhpStorm.
 * User: H.J.S.D
 * Date: 21/08/2016
 * Time: 09:25 PM
 */

namespace LnjGroup\Cms\Models;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    protected $table = "admin";
    protected $fillable = ['username', '', '', ''];
}