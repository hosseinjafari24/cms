<?php

namespace LnjGroup\Cms;

use Illuminate\Support\ServiceProvider;

class CmsServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind('cms', function () {
            return new Cms();
        });
//        $this->app->bind('laravel', function () {
//            return new Test();
//        });
        $this->mergeConfigFrom(__DIR__ . '/Configs/config.php','cms');
    }

    public function boot()
    {
        require __DIR__ . '\Http\routes.php';

        $this->loadViewsFrom(__DIR__ . '/Views', 'view');

        // ADD MIDDLEWARE INTO KERNEL
        $this->app['router']->middleware('admin',\LnjGroup\Cms\Http\Middleware\Admin::class);


        // PUBLISH FILE WITH METHOD
        $this->publishes([
            __DIR__.'/Configs/config.php'=>config_path('cms.php'),
        ],'config');

        $this->publishes([
            __DIR__.'/Views'=>  base_path('resources/views/cms')
        ],'views');

        $this->publishes([
            __DIR__ . '/Migrations'=> database_path('migrations')
        ],'migrations');

    }
}