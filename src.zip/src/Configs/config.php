<?php

return [
    'url' => 'lnj.ir/adminpanel',

    'name' => 'LnjGroup'
];