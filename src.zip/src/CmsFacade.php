<?php
/**
 * Created by PhpStorm.
 * User: H.J.S.D
 * Date: 20/08/2016
 * Time: 09:15 PM
 */

namespace LnjGroup\Cms;


use Illuminate\Support\Facades\Facade;

class CmsFacade extends Facade
{
    protected static function getFacadeAccessor(){
        return 'cms';
//        return 'laravel';
    }
}