<?php
/**
 * Created by PhpStorm.
 * User: H.J.S.D
 * Date: 20/08/2016
 * Time: 08:10 PM
 */

namespace LnjGroup\Cms;


use LnjGroup\Cms\Models\Admin;

class Cms
{
    public function listUser()
    {
        return ['hossein', 'javad'];
    }

    public function listAdmin()
    {
        return Admin::lists('username');
    }
}