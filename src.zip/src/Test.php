<?php
/**
 * Created by PhpStorm.
 * User: H.J.S.D
 * Date: 21/08/2016
 * Time: 10:29 AM
 */

namespace LnjGroup\Cms;


class Test
{
    public function myApp()
    {
        return 'Laravel and Angular is Best freamwork!';
    }
}